# MyCCTV — शुरुआती Android प्रोजेक्ट

यह पहला चरण है: कैमरा प्रीव्यू, फ्लैश टॉगल, स्थानीय वीडियो रिकॉर्डिंग और उसी सत्र में नवीनतम रिकॉर्डिंग खोलना।

## अभी शामिल नहीं
- दूसरे फोन पर लाइव स्ट्रीम
- इंटरनेट के ज़रिए रिमोट एक्सेस
- दो-तरफ़ा Talk
- ऐप बंद होने पर लगातार बैकग्राउंड रिकॉर्डिंग

## प्रोजेक्ट बनाना
1. इस ZIP को Extract करें।
2. Android Studio वाले कंप्यूटर पर फ़ोल्डर खोलें, या Android फोन पर किसी संगत Android Gradle IDE में खोलने की कोशिश करें।
3. Gradle sync पूरा होने दें और app चलाएँ।
4. कैमरा और माइक्रोफोन अनुमति दें।
5. `Record` दबाकर टेस्ट वीडियो बनाएँ। फ़ाइल `Movies/MyCCTV` में सेव होगी।

## ज़रूरी सूचना
- यह source project है, पहले से बना APK नहीं।
- Android SDK/Gradle के संस्करणों के कारण मोबाइल IDE में build में बदलाव की ज़रूरत पड़ सकती है।
- AndroidIDE का मूल प्रोजेक्ट archived/unmaintained है; production app के लिए अपडेटेड, maintained build environment बेहतर है।
- Remote Viewer जोड़ने से पहले authenticated pairing, encryption, consent indicators और सुरक्षित network signaling लागू करें।
