package com.mycctv.app

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.ComponentActivity
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    private lateinit var previewView: PreviewView
    private lateinit var status: TextView
    private lateinit var recordButton: Button
    private lateinit var flashButton: Button
    private lateinit var playbackButton: Button

    private var camera: Camera? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var recording: Recording? = null
    private var lastSavedUri: Uri? = null
    private var torchOn = false

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
            val granted = result[Manifest.permission.CAMERA] == true &&
                result[Manifest.permission.RECORD_AUDIO] == true
            if (granted) startCamera()
            else {
                status.text = "कैमरा और माइक्रोफोन अनुमति आवश्यक है।"
                toast("Settings में MyCCTV की आवश्यक permissions चालू करें।")
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        if (hasPermissions()) startCamera() else requestPermissionsNow()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 18, 18, 18)
            setBackgroundColor(0xFF10251D.toInt())
        }

        val title = TextView(this).apply {
            text = "MyCCTV"
            textSize = 26f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
        }
        root.addView(title, LinearLayout.LayoutParams(-1, 56))

        status = TextView(this).apply {
            text = "कैमरा शुरू हो रहा है…"
            textSize = 14f
            setTextColor(0xFFD4E8DD.toInt())
            gravity = Gravity.CENTER
        }
        root.addView(status, LinearLayout.LayoutParams(-1, 42))

        previewView = PreviewView(this).apply {
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        }
        root.addView(
            previewView,
            LinearLayout.LayoutParams(-1, 0, 1f).apply {
                bottomMargin = 12
            }
        )

        val modeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val cameraMode = makeButton("Camera Mode") {
            status.text = "Camera Mode: लाइव प्रीव्यू और रिकॉर्डिंग"
            if (camera == null) startCamera()
        }
        val viewerMode = makeButton("Viewer / Playback") {
            openPlayback()
        }
        modeRow.addView(cameraMode, LinearLayout.LayoutParams(0, 52, 1f).apply { rightMargin = 6 })
        modeRow.addView(viewerMode, LinearLayout.LayoutParams(0, 52, 1f).apply { leftMargin = 6 })
        root.addView(modeRow)

        val controlRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        flashButton = makeButton("Flash: OFF") { toggleFlash() }
        recordButton = makeButton("● Record") { toggleRecording() }
        controlRow.addView(flashButton, LinearLayout.LayoutParams(0, 54, 1f).apply { rightMargin = 6 })
        controlRow.addView(recordButton, LinearLayout.LayoutParams(0, 54, 1f).apply { leftMargin = 6 })
        root.addView(controlRow)

        playbackButton = makeButton("Play latest recording") { openPlayback() }
        root.addView(playbackButton, LinearLayout.LayoutParams(-1, 50).apply { topMargin = 8 })

        val note = TextView(this).apply {
            text = "यह शुरुआती संस्करण रिकॉर्डिंग फोन पर सेव करता है। दूरस्थ लाइव Viewer अभी शामिल नहीं है।"
            textSize = 12f
            setTextColor(0xFFB7CFC3.toInt())
            gravity = Gravity.CENTER
            setPadding(4, 10, 4, 0)
        }
        root.addView(note, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))
        setContentView(root)
    }

    private fun makeButton(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            isAllCaps = false
            setOnClickListener { action() }
        }

    private fun hasPermissions(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun requestPermissionsNow() {
        permissionLauncher.launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO))
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                val provider = future.get()
                val preview = Preview.Builder().build().also {
                    it.surfaceProvider = previewView.surfaceProvider
                }
                val recorder = Recorder.Builder()
                    .setQualitySelector(QualitySelector.from(Quality.HD))
                    .build()
                val capture = VideoCapture.withOutput(recorder)
                provider.unbindAll()
                camera = provider.bindToLifecycle(
                    this,
                    CameraSelector.DEFAULT_BACK_CAMERA,
                    preview,
                    capture
                )
                videoCapture = capture
                flashButton.isEnabled = camera?.cameraInfo?.hasFlashUnit() == true
                status.text = "Camera Mode: कैमरा तैयार है"
            } catch (e: Exception) {
                status.text = "कैमरा शुरू नहीं हुआ: ${e.localizedMessage ?: "अज्ञात त्रुटि"}"
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun toggleFlash() {
        val cam = camera ?: return toast("पहले कैमरा शुरू करें।")
        if (!cam.cameraInfo.hasFlashUnit()) {
            toast("इस फोन में उपलब्ध कैमरा फ्लैश नहीं मिला।")
            return
        }
        torchOn = !torchOn
        cam.cameraControl.enableTorch(torchOn)
        flashButton.text = if (torchOn) "Flash: ON" else "Flash: OFF"
    }

    private fun toggleRecording() {
        if (recording != null) {
            recording?.stop()
            recording = null
            recordButton.text = "● Record"
            status.text = "रिकॉर्डिंग रोक दी गई।"
            return
        }

        val capture = videoCapture ?: return toast("कैमरा अभी तैयार नहीं है।")
        val name = "MyCCTV_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "$name.mp4")
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/MyCCTV")
        }
        val output = MediaStoreOutputOptions.Builder(
            contentResolver,
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        ).setContentValues(values).build()

        try {
            var pending = capture.output.prepareRecording(this, output)
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
                PackageManager.PERMISSION_GRANTED
            ) {
                pending = pending.withAudioEnabled()
            }
            recording = pending.start(ContextCompat.getMainExecutor(this)) { event ->
                when (event) {
                    is VideoRecordEvent.Start -> {
                        recordButton.text = "■ Stop"
                        status.text = "REC — वीडियो सेव हो रहा है"
                    }
                    is VideoRecordEvent.Finalize -> {
                        recording = null
                        recordButton.text = "● Record"
                        if (!event.hasError()) {
                            lastSavedUri = event.outputResults.outputUri
                            status.text = "रिकॉर्डिंग सेव हो गई।"
                            toast("वीडियो Movies/MyCCTV में सेव हुआ।")
                        } else {
                            status.text = "रिकॉर्डिंग में त्रुटि: ${event.error}"
                            toast("रिकॉर्डिंग सेव नहीं हो सकी।")
                        }
                    }
                }
            }
        } catch (e: Exception) {
            status.text = "रिकॉर्डिंग शुरू नहीं हुई: ${e.localizedMessage ?: "त्रुटि"}"
        }
    }

    private fun openPlayback() {
        val uri = lastSavedUri
        if (uri == null) {
            toast("पहले एक वीडियो रिकॉर्ड करें। वीडियो Movies/MyCCTV में भी मिलेगा।")
            return
        }
        try {
            val intent = android.content.Intent(android.content.Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "video/mp4")
                addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(intent)
        } catch (_: Exception) {
            toast("वीडियो चलाने के लिए कोई player उपलब्ध नहीं है।")
        }
    }

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }

    override fun onDestroy() {
        recording?.stop()
        super.onDestroy()
    }
}
